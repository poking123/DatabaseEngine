
public class SumAggregate {

}
