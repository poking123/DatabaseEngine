
public abstract class Predicate {
	abstract String getType();
}
