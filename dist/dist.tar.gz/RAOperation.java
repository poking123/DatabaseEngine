import java.util.Queue;

public abstract class RAOperation implements Iterable<Queue<int[]>> {
	abstract String getType();
}
