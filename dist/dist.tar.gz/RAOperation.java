import java.util.List;

public abstract class RAOperation implements Iterable<List<int[]>> {
	abstract String getType();
}
